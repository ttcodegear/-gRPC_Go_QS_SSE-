package main

import (
  "log"
  "context"
  "google.golang.org/grpc"
  pb "simple/pb/greeter_server"
)

func main() {
  conn, err := grpc.Dial("localhost:50051", grpc.WithInsecure())
  if err != nil {
    log.Fatalf("%v", err)
    return
  }
  defer conn.Close()

  client := pb.NewGreeterClient(conn)
  request := pb.HelloRequest{ Name: "山田太郎" }
  reply, err := client.SayHello(context.Background(), &request)
  if err != nil {
    log.Fatalf("%v", err)
    return
  }
  log.Printf("Greeter client received: %s", reply.Message)
}
