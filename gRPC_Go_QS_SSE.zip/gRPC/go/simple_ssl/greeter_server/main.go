package main

import (
  "fmt"
  "log"
  "net"
  "context"
  "google.golang.org/grpc"
  "google.golang.org/grpc/credentials"
  pb "simple_ssl/pb/greeter_server"
)

type GreeterServer struct {
  pb.UnimplementedGreeterServer
}

func (s *GreeterServer) SayHello(ctx context.Context, in *pb.HelloRequest) (*pb.HelloReply, error) {
  log.Printf("Received request: %v", in)
  reply := fmt.Sprintf("こんにちは %s!", in.Name)
  return &pb.HelloReply{Message: reply}, nil
}

func main() {
  listen, err := net.Listen("tcp", ":50051")
  if err != nil {
    log.Fatalf("%v", err)
    return
  }
  serverCert, err := credentials.NewServerTLSFromFile("server.crt", "server.key")
  if err != nil {
    log.Fatalf("%v", err)
    return
  }
  s := grpc.NewServer(grpc.Creds(serverCert))
  var server GreeterServer
  pb.RegisterGreeterServer(s, &server)
  err = s.Serve(listen)
  if err != nil {
    log.Fatalf("%v", err)
  }
}
