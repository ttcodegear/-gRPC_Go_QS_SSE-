package main

import (
  "fmt"
  "log"
  "net"
  "strconv"
  "io"
  "google.golang.org/grpc"
  pb "stream/pb/greeter_server"
)

type MultiGreeterServer struct {
  pb.UnimplementedMultiGreeterServer
}

func (s *MultiGreeterServer) SayHello(stream pb.MultiGreeter_SayHelloServer) error {
  for {
    in, err := stream.Recv()
    if err == io.EOF {
      return nil
    }
    if err != nil {
      return err
    }
    log.Printf("Received request: %v", in)
    name := in.Name
    num, _ := strconv.ParseInt(in.NumGreetings, 10, 64)
    for i := int64(0); i < num; i++ {
      reply := pb.HelloReply{ Message: fmt.Sprintf("こんにちは %s! %d", name, i) }
      
      if err := stream.Send(&reply); err != nil {
        return err
      }
    }
  }
}

func main() {
  listen, err := net.Listen("tcp", ":50052")
  if err != nil {
    log.Fatalf("%v", err)
    return
  }
  s := grpc.NewServer()
  var server MultiGreeterServer
  pb.RegisterMultiGreeterServer(s, &server)
  err = s.Serve(listen)
  if err != nil {
    log.Fatalf("%v", err)
  }
}
