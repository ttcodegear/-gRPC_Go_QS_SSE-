package main

import (
  "log"
  "context"
  "io"
  "google.golang.org/grpc"
  pb "stream/pb/greeter_server"
)

func main() {
  conn, err := grpc.Dial("localhost:50052", grpc.WithInsecure())
  if err != nil {
    log.Fatalf("%v", err)
    return
  }
  defer conn.Close()

  client := pb.NewMultiGreeterClient(conn)
  request1 := pb.HelloRequest{ Name: "山田太郎", NumGreetings: "5" }
  request2 := pb.HelloRequest{ Name: "FooBar", NumGreetings: "5" }
  stream, err := client.SayHello(context.Background())
  if err != nil {
    log.Fatalf("%v", err)
    return
  }
  stream.Send(&request1)
  stream.Send(&request2)
  stream.CloseSend()
  for {
    reply, err := stream.Recv()
    if err == io.EOF {
      break
    }
    if err != nil {
      log.Fatalf("%v", err)
      break
    }
    log.Printf("Greeter client received: %s", reply.Message)
  }
}
